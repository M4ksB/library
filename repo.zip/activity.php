<?php

    include "navigation.php";
    include "bd.php";

    $curDate = GETDATE();



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="container_Header">
            <h1>Мероприятия</h1>
            <div class="borderBlock"></div>
        </div>

        <div class="activities">
            <div class="past">
                <h1>Прошедшие события</h1>
                    <table class="table">
                        <tr>
                            <td class="bry-d">Название Мероприятия</td>
                            <td>Дата</td>
                        </tr>
                    <?php
                            $past = "SELECT name, date FROM activity WHERE date <= now()";
                            $execPast = mysqli_query($mysqli, $past);
                            while ($row = mysqli_fetch_array($execPast)){
                                echo "<tr>";
                                echo "<td class='bry-d'>" . $row['name'] . "</td>";
                                echo "<td>" . $row['date'] . "</td>";
                                echo "</tr>";
                            }
                    ?>
                    </table>

            </div>
            <div class="coming">
                <h1>Предстоящие события</h1>
                <table class="table">
                    <tr>
                            <td class="bry-d">Название Мероприятия</td>
                            <td>Дата</td>
                    </tr>
                    <?php
                            $coming = "SELECT name, date FROM activity WHERE date > now()";
                            $execComing = mysqli_query($mysqli, $coming);
                            while ($row = mysqli_fetch_array($execComing)){
                                echo "<tr>";
                                echo "<td class='bry-d'>" . $row['name'] . "</td>";
                                echo "<td>" . $row['date'] . "</td>";
                                echo "</tr>";
                            }
                    ?>
                </table>
                <div class="edit_buttons">
                    <button class="btn" onclick="window.location.href='addActivity.php'">Добавить Мероприятие</button>
                    <button class="btn" onclick="window.location.href='changeActivity.php'">Редактировать Мероприятие</button>
                    <button class="btn" onclick="window.location.href='deleteActivity.php'">Удалить Мероприятие</button>
                </div>
            </div>
        </div>

    </div>
</body>
</html>