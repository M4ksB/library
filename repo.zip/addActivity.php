<?php

    include "navigation.php";
    include "bd.php";
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">   
        <div class="container_Header">
            <h1>Добавить Мероприятие</h1>
            <div class="borderBlock"></div>
        </div>
        <form action="php/addActivity.php" method="POST" class="form">
            <input type="text" name="activityName" placeholder="Введите название мероприятия">
            <input type="date" name="activityDate" placeholder="Введите дату мероприятия">
            <input type="submit" value="Добавить" class="btn">
        </form>


</div>

</body>
</html>
