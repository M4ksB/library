<?php

    include "navigation.php";
    include "bd.php";
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">   
        <div class="container_Header">
            <h1>Добавить книгу</h1>
            <div class="borderBlock"></div>
        </div>
        <form action="php/addBook.php" method="POST" class="form">
            <input type="text" name="bookName" placeholder="Введите название книги">
            <input type="text" name="authorFIO" placeholder="Введите автора книги">
            <input type="submit" value="Добавить" class="btn">
        </form>


</div>

</body>
</html>