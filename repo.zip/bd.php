<?php 
  $host = 'localhost';
  $user = 'f0524234_root';
  $password = 'admin';
  $db_name = "f0524234_library";
  
  $mysqli = mysqli_connect($host, $user, $password, $db_name)
    or die(mysqli_error($link));
?>