<?php

    include "bd.php";
    include "navigation.php";

    $name = "SELECT bookName FROM books";
    $author = "SELECT authorFIO FROM books";
    $date = "SELECT addDate FROM books";

    $test = "SELECT ID, bookName, authorFIO, addDate FROM books";

    $exec = mysqli_query($mysqli, $test);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Книги</title>
</head>
<body>
<div class="container">  
    <div class="container_Header">
        <h1>Список книг:</h1>
        <div class="borderBlock"></div>
    </div>

    <div class="table_box">

    <table class="table">
        <tr>
            <td class='bry-d'>Номер книги</td>
            <td class='bry-d'>Название книги</td>
            <td class='bry-d'>ФИО автора</td>
            <td>Дата добавления</td>
        </tr>
            <?php   
                while ($row = mysqli_fetch_array($exec)){
                    echo "<tr>";
                    echo "<td class='bry-d'>" . $row['ID'] . "</td>" ;
                    echo "<td class='bry-d'>" . $row['bookName'] . "</td>";
                    echo "<td class='bry-d'>" . $row['authorFIO'] . "</td>";
                    echo "<td>" . $row['addDate'] . "</td>";
                    echo "</tr>";
                }
            ?>
    </table>
    </div>

    


    <div class="edit_buttons">
        <button class="btn" onclick="window.location.href='addBook.php'">Добавить Книгу</button>
        <button class="btn" onclick="window.location.href='changeBook.php'">Редактировать Книгу</button>
        <button class="btn" onclick="window.location.href='deleteBook.php'">Удалить Книгу</button>
    </div>
</div>

</body>
</html>