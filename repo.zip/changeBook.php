<?php

    include "navigation.php";
    include "bd.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Библиотека</title>
</head>
<body>
    <div class="container">
    <div class="container_Header">
            <h1>Изменение книги</h1>
            <div class="borderBlock"></div>
        </div>
        <form action="php/changeBook.php" class="form" method="POST">
            <input type="text" name="id" placeholder="Введите номер книги для изменения">
            <input type="text" name="name" placeholder="Введите новое название">
            <input type="text" name="fio" placeholder="Введите нового автора">
            <input type="submit" class="btn" value="Изменить">
        </form> 
    </div>
   
</body>
</html>
