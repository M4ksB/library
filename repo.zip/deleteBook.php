<?php

    include "bd.php";
    include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Библиотека</title>
</head>
<body>
    <div class="container">
    <div class="container_Header">
            <h1>Удаление книги</h1>
            <div class="borderBlock"></div>
        </div>
        <form action="php/deleteBook.php" class="form" method="POST">
            <input type="text" name="id" placeholder="Введите номер книги для Удаления">
            <input type="submit" class="btn" value="Удалить">
        </form> 
    </div>
</body>
</html>
