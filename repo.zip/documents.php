<?php

    include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
    <div class="container_Header">
        <h1>Документы</h1>
        <div class="borderBlock"></div>
    </div>
        <div class="documentsList">
            <a href="usageDoc.php" target="_blank">Правила пользования</a>
        </div>
    </div>
</body>
</html>