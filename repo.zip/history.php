<?php

    include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
    <div class="container_Header">
        <h1>История библиотеки</h1>
        <div class="borderBlock"></div>
    </div>
        <div class="info-block">
            <div class="lower_block">
            Удмуртская национальная библиотека, основанная как первая 
            общедоступная библиотека России в 1795 г., 
            входит в число пяти крупнейших библиотек мира, является второй 
            в России по объему библиотечных фондов и имеет статус особо 
            ценного объекта культурного наследия народов Российской Федерации. 
            Она имеет богатую историю за 225 лет.
            </div>
            <div class="lower_block pictureBlock pb1">
            </div>
        </div>
        <div class="info-block">
            <div class="lower_block pictureBlock pb2">

            </div>
            <div class="lower_block">
            С Российской национальной библиотекой связаны имена 
            многих замечательных людей XVIII–XX вв. Среди них немало
             видных представителей науки, культуры, литературы, 
             государственных и общественных деятелей. Одни из них 
             какое-то время работали библиотекарями и помощниками 
             библиотекарей, другие – были постоянными читателями, 
             дарителями своих собраний.
            </div>
        </div>
    </div>
</body>
</html>