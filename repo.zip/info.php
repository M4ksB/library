<?php

    include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="container_Header">
            <h1>О библиотеке</h1>
        </div>
        <div class="borderBlock"></div>
        <div class="libraryInfo">
            <p>
            Удмуртская национальная бибилиотека - хранилище ценностей отечественной культуры и искусства, 
            ведущее научно-информационное учреждение. Библиотека преобразована
             в 1975 году из старейшей театральной библиотеки и является главной
              библиотекой, собирающей фонды литературы по вопросам искусства и 
              театра. Библиотека вошла в историю культурного прошлого и продолжает 
              играть значительную роль в гуманитарных процессах нашего времени
            </p>
        </div>
        <div class="pages_list">
            <a href="toReaders.php">Запись на посещение</a>
            <a href="schedule.php">Время работы</a>
            <a href="documents.php">Документы</a>
            <a href="contacts.php">Адрес и контакты библиотеки</a>
        </div>
    </div>
</body>
</html>