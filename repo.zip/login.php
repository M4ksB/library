<?php

include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
</head>
<body>
<div class="container">
    <div class="container_Header">
        <h1>Авторизация</h1>
        <div class="borderBlock"></div>
    </div>
<div class="login">
        <form action="log.php" class="login_Form" method="POST">
            <input type="text" placeholder="Введите ваш логин" name="login" required>
            <input type="password" placeholder="Введите ваш пароль" name="password" required>
            <input type="submit" class="btn" value="Войти">
            <p>Нет аккаунта?<a href="register.php"> Регистрация</a></p>
        </form>

    </div>
</div>
</body>
</html>
