<?php

    include "bd.php";
    session_start();
    session_destroy();
    $id = $_SESSION['id'];
    
    header("location:index.php");

?>