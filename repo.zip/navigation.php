
    <link rel="stylesheet" href="css/style.css">
    <header class="header">
        <div class="navigation_logo">
            <a href="index.php"><img src="img/logo.png"></a>
        </div>
            <ul class="navigation_menu">
                <li><a href="toReaders.php">Читателям</a>
                    <ul class="submenu">
                        <li><a href="profile.php">Личный кабинет</a></li>
                        <li><a href="books.php">Список Книг</a></li>
                        <li><a href="schedule.php">Режим работы</a></li>
                    </ul>
                </li>
                <li style="width:89.89px;"><a href="resources.php">Ресурсы</a>
                    <ul class="submenu">
                        <li><a href="activity.php">Деятельность</a></li>
                        <li><a href="projects.php">Проекты</a></li>
                    </ul>
                </li>
                <li><a href="info.php">О библиотеке</a>
                    <ul class="submenu">
                        <li><a href="history.php">История библиотеки</a></li>
                        <li><a href="documents.php">Документы</a></li>
                    </ul>
                </li>
                <li><a href="contacts.php">Контакты</a>
                </li>
            </ul>




            <div class="navigation_menu_mobile" id="menu">
            <a href="toReaders.php">Читателям</a>
            <a href="profile.php">Личный кабинет</a>
            <a href="books.php">Список Книг</a>
            <a href="schedule.php">Режим работы</a>
            <a href="resources.php">Ресурсы</a>
            <a href="activity.php">Деятельность</a>
            <a href="projects.php">Проекты</a>
            <a href="info.php">О библиотеке</a>
            <a href="history.php">История библиотеки</a>
            <a href="documents.php">Документы</a>
            <a href="contacts.php">Контакты</a>
            </div>
            <button class="btn" id="show"><img src="img/menu.png" style="width:40px;height:40px;" alt=""></button>

</header>

<script>

let showMenu = document.getElementById('show');
let menu = document.getElementById('menu');

showMenu.onclick = function() {
    menu.classList.toggle('navigation_menu_show');
  }

</script>