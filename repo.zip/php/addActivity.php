<?php 
  $host = 'localhost';
  $user = 'root';
  $password = '';
  $db_name = "library";
  
  $mysqli = mysqli_connect($host, $user, $password, $db_name)
    or die(mysqli_error($link));
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Document</title>
    <header class="header">
        <div class="navigation_logo">
            <a href="../index.php"><img src="../img/logo.png"></a>
        </div>
            <ul class="navigation_menu">
                <li><a href="../toReaders.php">Читателям</a>
                    <ul class="submenu">
                        <li><a href="../profile.php">Личный кабинет</a></li>
                        <li><a href="../books.php">Список Книг</a></li>
                        <li><a href="../schedule.php">Режим работы</a></li>
                    </ul>
                </li>
                <li style="width:89.89px;"><a href="../resources.php">Ресурсы</a>
                    <ul class="submenu">
                        <li><a href="../activity.php">Деятельность</a></li>
                        <li><a href="../projects.php">Проекты</a></li>
                    </ul>
                </li>
                <li><a href="../info.php">О библиотеке</a>
                    <ul class="submenu">
                        <li><a href="../history.php">История библиотеки</a></li>
                        <li><a href="../documents.php">Документы</a></li>
                    </ul>
                </li>
                <li><a href="../contacts.php">Контакты</a>
                </li>
            </ul>
    </header>
</head>
<body>
    <div class="container">   
        <div class="container_Header">
            <h1>Добавить Мероприятие</h1>
            <div class="borderBlock"></div>
        </div>
        <form action="addActivity.php" method="POST" class="form">
            <input type="text" name="activityName" placeholder="Введите название мероприятия">
            <input type="date" name="activityDate" placeholder="Введите дату мероприятия">
            <input type="submit" value="Добавить" class="btn">
        </form>
<?php

$name = $_POST['activityName'];
$date = $_POST['activityDate'];

if (!empty($name) && !empty($date)) {
$add = mysqli_query($mysqli, "INSERT INTO activity (id, name, date) 
VALUES (NULL, '$name', '$date')");

    if ($add == true) {
        echo "Мероприятие добавлено";
    } else {
        echo "Не удалось добавить мероприятие";
    }
} else {
    echo "Заполните все поля";
}
?>

</div>

</body>
</html>
