<?php 
  $host = 'localhost';
  $user = 'root';
  $password = '';
  $db_name = "library";
  
  $mysqli = mysqli_connect($host, $user, $password, $db_name)
    or die(mysqli_error($link));
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/style.css">
    <header class="header">
        <div class="navigation_logo">
            <a href="../index.php"><img src="../img/logo.png"></a>
        </div>
            <ul class="navigation_menu">
                <li><a href="../toReaders.php">Читателям</a>
                    <ul class="submenu">
                        <li><a href="../profile.php">Личный кабинет</a></li>
                        <li><a href="../books.php">Список Книг</a></li>
                        <li><a href="../schedule.php">Режим работы</a></li>
                    </ul>
                </li>
                <li style="width:89.89px;"><a href="../resources.php">Ресурсы</a>
                    <ul class="submenu">
                        <li><a href="../activity.php">Деятельность</a></li>
                        <li><a href="../projects.php">Проекты</a></li>
                    </ul>
                </li>
                <li><a href="../info.php">О библиотеке</a>
                    <ul class="submenu">
                        <li><a href="../history.php">История библиотеки</a></li>
                        <li><a href="../documents.php">Документы</a></li>
                    </ul>
                </li>
                <li><a href="../contacts.php">Контакты</a>
                </li>
            </ul>
    </header>
</head>
<body>
    <div class="container">   
        <div class="container_Header">
            <h1>Добавить книгу</h1>
            <div class="borderBlock"></div>
        </div>
        <form action=php/addBook.php" method="POST" class="form">
            <input type="text" name="bookName" placeholder="Введите название книги">
            <input type="text" name="authorFIO" placeholder="Введите автора книги">
            <input type="submit" value="Добавить" class="btn">
        </form>

<?php

$name = $_POST['bookName'];
$fio = $_POST['authorFIO'];
$date = GETDATE();
$d = "$date[year]-$date[mon]-$date[mday]";

if (!empty($name) && !empty($fio)) {
$add = mysqli_query($mysqli, "INSERT INTO books (id, bookName, authorFIO, addDate) 
VALUES (NULL, '$name', '$fio', '$d')");

    if ($add == true) {
        echo "Книга добавлена";
    } else {
        echo "Не удалось добавить книгу";
    }
} else  if (empty($name) || empty($fio)){
    echo "Заполните все поля";
}
?>

</div>

</body>
</html>