<?php 
  $host = 'localhost';
  $user = 'root';
  $password = '';
  $db_name = "library";
  
  $mysqli = mysqli_connect($host, $user, $password, $db_name)
    or die(mysqli_error($link));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Библиотека</title>
    <link rel="stylesheet" href="../css/style.css">
    <header class="header">
        <div class="navigation_logo">
            <a href="../index.php"><img src="../img/logo.png"></a>
        </div>
            <ul class="navigation_menu">
                <li><a href="../toReaders.php">Читателям</a>
                    <ul class="submenu">
                        <li><a href="../profile.php">Личный кабинет</a></li>
                        <li><a href="../books.php">Список Книг</a></li>
                        <li><a href="../schedule.php">Режим работы</a></li>
                    </ul>
                </li>
                <li style="width:89.89px;"><a href="../resources.php">Ресурсы</a>
                    <ul class="submenu">
                        <li><a href="../activity.php">Деятельность</a></li>
                        <li><a href="../projects.php">Проекты</a></li>
                    </ul>
                </li>
                <li><a href="../info.php">О библиотеке</a>
                    <ul class="submenu">
                        <li><a href="../history.php">История библиотеки</a></li>
                        <li><a href="../documents.php">Документы</a></li>
                    </ul>
                </li>
                <li><a href="../contacts.php">Контакты</a>
                </li>
            </ul>
    </header>
</head>
<body>
    <div class="container">
    <div class="container_Header">
            <h1>Изменение книги</h1>
            <div class="borderBlock"></div>
        </div>
        <form action="changeBook.php" class="form" method="POST">
            <input type="text" name="id" placeholder="Введите номер книги для изменения">
            <input type="text" name="name" placeholder="Введите новое название">
            <input type="text" name="fio" placeholder="Введите нового автора">
            <input type="submit" class="btn" value="Изменить">
        </form> 

<?php
    $id = $_POST['id'];
    $name = $_POST['name'];
    $fio = $_POST['fio'];

if (!empty($id) && !empty($name) && !empty($fio)) {
    $change = mysqli_query($mysqli, "UPDATE books SET bookName = '$name', authorFIO = '$fio' WHERE id = '$id'");
    if ($change == true) {
        echo "Книга успешно изменена";
    } else {
        echo "Не удалось изменить книгу";   
    }
} else {
    echo "Заполните все поля";
}
?>

</div>
   
   </body>
   </html>   