<?php

    include "bd.php";
    include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
</head>
<body>
    <div class="container">
        <div class="container_Header">
            <h1>Ваш профиль</h1>
            <div class="borderBlock"></div>
        </div>
        <div class="profile_main">
            <button class="btn" id="btn" onclick="window.location.href = 'register.php';">Регистрация</button>
            <button class="btn" id="btn" onclick="window.location.href = 'login.php';">Вход</button>
        </div>
    </div>


</body>
</html>