<?php

    include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="container_Header">
            <h1>Проекты</h1>
            <div class="borderBlock"></div>
        </div>
        <div class="projectList">
            <div class="project_card" id="card1">
                <img src="img/award1.jpg" alt="">
                <p class="card_name">Премия читателя</p>
            </div>
            <div class="project_card" id="card2">
                <img src="img/prof.jpg" alt="">
                <p class="card_name">Лабиринты профессий</p>
            </div>
            <div class="project_card" id="card3">
                <img src="img/auditorium.png" alt="">
                <p class="card_name">Подкаст "Аудитория"</p>
            </div>
        </div>


            <div class="modal" id="modal1">
                <div class="modal_content">
                    <div class="modalcontent_top">
                        <h1>Проект "Премия читателя"</h1>
                    </div>
                    <div class="modalcontent_center">
                        <p>
                        Первая в российском библиотечном сообществе 
                        литературная награда. Вручается автору лучшей 
                        русскоязычной книги за прошедший год в номинациях 
                        «Художественная проза» и «Документальная проза 
                        (Non-Fiction)» по результатам анализа читательского 
                        спроса в библиотеках России (печатные и электронные
                         издания), а также финального голосования Жюри, 
                         состоящего из читателей библиотек в возрасте от 18 
                         до 35 лет.

                        Премия была учреждена Российской государственной 
                        библиотекой для молодёжи в конце 2015 года при поддержке
                         Министерства культуры России, Российской библиотечной
                          ассоциации (РБА).
                        </p>
                    </div>
                    <div class="modalcontent_bottom">

                    </div>
                </div>
            </div>


            <div class="modal" id="modal2">
                <div class="modal_content">
                    <div class="modalcontent_top">
                        <h1>Проект "Лабиринты профессий"</h1>
                    </div>
                    <div class="modalcontent_center">
                        <p>
                        «Лабиринты профессий» — проект для молодёжи, в 
                         рамках которого специалисты в области 
                         профориентации, образования, технологий,
                          крупного и малого бизнеса постараются ответить
                           на одни из самых важных вопросов, волнующих 
                           молодых людей, — как найти себя в жизни, как 
                           выбрать профессию по душе и при этом получать
                            стабильный доход, какие навыки будут
                            востребованы в будущем, как и где им
                             научиться.


                        </p>
                    </div>
                    <div class="modalcontent_bottom">

                    </div>
                </div>
            </div>


            <div class="modal" id="modal3">
                <div class="modal_content">
                    <div class="modalcontent_top">
                        <h1>Подкаст "Аудитория"</h1>
                    </div>
                    <div class="modalcontent_center">
                        <p>
                        «Аудитория» — Мы говорим о культуре — с 
                        интересом и предлагаем узнать неизвестные 
                        факты об известных событиях. Загадки истории 
                        и тайны книг, удивительные биографии и 
                        занимательное из мира кино и искусств. 
                        Обо всём этом и о многом другом рассказывают 
                        учёные, журналисты, писатели и критики.


                        </p>
                    </div>
                    <div class="modalcontent_bottom">

                    </div>
                </div>
            </div>


    </div>
</body>
<script src="js/script.js"></script>
</html>