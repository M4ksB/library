<?php

include "bd.php";
include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Библиотека</title>
</head>
<body>
	<div class="container">
	<div class="container_Header">
        <h1>Регистрация</h1>
        <div class="borderBlock"></div>
    </div>
    <div class="register">
        <form action="reg.php" method="POST" class="register_Form">
            <input type="text" placeholder="Введите ваш логин" name="login" required>
            <input type="text" placeholder="Введите ваш пароль" name="password" required>
            <input type="mail" placeholder="Введите вашу почту" name="mail" required>
            <input type="text" placeholder="Введите ваше ФИО" name="fio" required>
            <input type="submit" class="btn" value="Регистрация">
            <p>Уже есть аккаунт?<a href="login.php"> Войти</a></p>
        </form>
    </div>
<?php

$login = $_POST['login'];
$password = $_POST['password'];
$mail = $_POST['mail'];
$fio = $_POST['fio'];

function clean ($value = "") {
	$value = trim($value);
	$value = stripslashes($value);
	$value = strip_tags($value);
	$value = htmlspecialchars($value);

	return $value;
}


if (!empty($login) && !empty($password)  && !empty($mail) && !empty($fio)) {
	$searchUser = mysqli_query($mysqli, "SELECT login FROM users WHERE (login = $login)");
	if ($searchUser == true) {
		echo "Данный логин уже занят";
	} else {
	$result = mysqli_query($mysqli,"INSERT INTO `users` (id, login, password, mail, FIO, admin) VALUES (NULL, '$login', '$password', '$mail', '$FIO', 0)");
	if ($result == true) {
		echo "Пользователь зарегистрирован";
	} else {
		echo "Неудачная регистрация";
	} 
}}
else {
	echo "Заполните все поля";
}

?>

</div>
</body>
</html>
