<?php

include "navigation.php"

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
</head>
<body>
<div class="container">
<div class="container_Header">
        <h1>Регистрация</h1>
        <div class="borderBlock"></div>
    </div>
    <div class="register">
        <form action="reg.php" method="POST" class="register_Form">
            <input type="text" placeholder="Введите ваш логин" name="login">
            <input type="text" placeholder="Введите ваш пароль" name="password">
            <input type="mail" placeholder="Введите вашу почту" name="mail">
            <input type="text" placeholder="Введите ваше ФИО" name="fio">
            <input type="submit" class="btn" value="Регистрация">
            <p>Уже есть аккаунт?<a href="login.php"> Войти</a></p>
        </form>
    </div>
</div>
</body>
</html>