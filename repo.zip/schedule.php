<?php

    include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="container_Header"> 
            <h1>Режим работы</h1>
            <div class="borderBlock"></div>
        </div>
        <div class="main">
                <div class="table">
                    <h2>Часы работы библиотеки</h2>
                    <div class="table_row b-b b-t">
                        <div class="table_cell">
                            Понедельник - Суббота
                        </div>
                        <div class="table_cell">
                            С 9:00 до 19:00
                        </div>
                    </div>
                    <div class="table_row b-b">
                        <div class="table_cell">
                            Воскресенье
                        </div>
                        <div class="table_cell">
                            Выходной
                        </div>
                    </div>
                </div>
            <div class="table">
                <h2>График работы читальных залов</h2>
                    <div class="table_row b-b b-t">
                        <div class="table_cell">
                            Понедельник - Суббота
                        </div>
                        <div class="table_cell">
                            С 10:00 до 18:00
                        </div>
                    </div>
                    <div class="table_row b-b">
                        <div class="table_cell">
                            Воскресенье
                        </div>
                        <div class="table_cell">
                            Выходной
                        </div>
                    </div>
            </div>
            <div class="table">
                <h2>График работы выставочных залов</h2>
                    <div class="table_row b-t b-b">
                        <div class="table_cell">
                            Понедельник - Суббота
                        </div>
                        <div class="table_cell">
                            с 9:00 до 19:00
                        </div>
                    </div>
                    <div class="table_row b-b">
                        <div class="table_cell">
                            Воскресенье
                        </div>
                        <div class="table_cell">
                            Выходной
                        </div>
                    </div>
            </div>

        </div>
    </div>
</body>
</html>