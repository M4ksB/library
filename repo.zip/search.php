<?php

    include "bd.php";
    include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="search_main mt-100">
    <?php

        $name = $_POST['writedName'];
        $search = "SELECT * FROM books WHERE bookName LIKE '%" . $name . "%'";

        $result = mysqli_query($mysqli, $search);
        $nums = "SELECT COUNT(*) FROM books WHERE bookname LIKE '%" . $name . "%'";
        $numsResult = mysqli_query($mysqli, $nums);
        $numResult = mysqli_fetch_array($numsResult);
         
        if($numResult[0] == 0) {
            $term = "";
        } else if($numResult[0] == 1 ) {
            $term = "а";
        } else if($numResult[0] > 1 ) {
            $term = "и";
        } else if($numResult[0] >= 5 ) 
        {
            $term = "";
        }

echo "Найдено " . $numResult[0] . " книг" . $term. "<br>";



        while ($row = mysqli_fetch_array($result)) {
            $bookName = $row['bookName'];
            $author = $row['authorFIO'];
            $date = $row['addDate'];

                    echo "<table><tr>";
                    echo "<td style='width:150px;'>" . $bookName . " </td><td style='width:300px;'>" . $author . " </td><td style='width:110px;'>" . $date;
                    echo "</td  ></table></tr>";

        }

    ?>
    </div>
</div>
</body>
</html>