<?php

include "bd.php";
include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Библиотека</title>
</head>
<body>
    <div class="container">
        <div class="container_Header">
            <h1>Контактная информация</h1>
            <div class="borderBlock"></div>
        </div>
        <form action="sendQuestion.php" method="POST" class="form"> 
            <input type="mail" placeholder="Введите вашу почту">
            <textarea name="question" cols="37" rows="5" placeholder="Опишите ваш вопрос"></textarea>
            <input type="submit" class="btn">
        </form>

<?php

$mail = $_POST['mail'];
$question = $_POST['question'];

$query = "INSERT INTO questions (mail, text) VALUES ('$mail', '$question')";

if (!empty($mail) && !empty($question)) {
$result = mysqli_query($mysqli, $query);
} else {
    echo "Заполните все поля";
}

if ($result == true) {
    echo "Ваш запрос отправлен";
}  

?>

<div class="contacts">
            <br><h3>E-Mail:</h3> biblForFor@bibl.ru
            <br><h3>Тел.:</h3>   
            <br><h3>Адрес:</h3>  469456, Россия, Г.Ижевск, Библиотечная ул., 46

        </div>
</div>
</body>
</html>