<?php

include "bd.php";
include "navigation.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Библиотека</title>
</head>
<body>
    <div class="container">
        <div class="bg1">
            <form action="search.php" class="search_Form" method="POST">
                <input type="text" placeholder="Введите название книги" name="writedName">
                <input type="submit" value="Поиск" class="btn">
            </form>
        </div>
        <div class="info">
            <h2 style="margin-top:20px;">Читателям</h2>
            <h3 style="margin:10px;">Часы работы библиотеки</h3>
            <p>пн–сб: 9:00-19:00;  вс: Выходной</p>
        </div>
        <div class="contactsTable">
        <form action="sendQuestionMain.php" method="POST" class="form"> 
            <h3 class="white">Задайте нам вопрос</h3>
            <input type="mail" placeholder="Введите вашу почту" name="mail">
            <textarea name="question" cols="37" rows="5" placeholder="Опишите ваш вопрос"></textarea>
            <input type="submit" class="btn">
        </form>

<?php

$mail = $_POST['mail'];
$question = $_POST['question'];

$query = "INSERT INTO questions (mail, text) VALUES ('$mail', '$question')";

if (!empty($mail) && !empty($question)) {
$result = mysqli_query($mysqli, $query);
} else {
    echo "Заполните все поля";
}

if ($result == true) {
    echo "Ваш запрос отправлен";
}  

?>


</div>
</body>
</html>