<?php

    include "bd.php";
    include "navigation.php";

    $test = "SELECT visitorFIO, visitDate, visitTime FROM visit";

    $exec = mysqli_query($mysqli, $test);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Читателям</title>
        <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <div class="container_Header">
        <h1>Запись на посещение библиотеки</h1>
        <div class="borderBlock"></div>
    </div>
    <div class="readers_main">
        <button class="btn" onclick="window.location.href = 'visit.php';">Записаться</button>
    </div>
        <div class="table_box">
        <table class="table">
            <tr>
                <td>ФИО посетителя</td>
                <td>Дата посещения</td>
                <td>Время посещения</td>
            </tr>

            <?php

                while ($row = mysqli_fetch_array($exec)){
                    echo "<tr>";
                    echo "<td>" . $row['visitorFIO'] . "</td>";
                    echo "<td>" . $row['visitDate'] . "</td>";
                    echo "<td>" . $row['visitTime'] . "</td>";
                    echo "</tr>";
                }
            ?>

        </table>
        </div>
</div>
</body>
</html>