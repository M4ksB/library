<?php

include  "navigation.php";


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
        <div class="container_Header">
            <h1>Запись на посещение</h1>
            <div class="borderBlock"></div>
        </div>
        <form class="form" method="POST" action="visitAdd.php">
        <input type="text" placeholder="Введите ваше ФИО" name="fio">
        <input type="date" name="date">
        <input type="time" name="time">
        <input type="submit" class="btn" placeholder="Записаться">
        </form>

<?php
$fio = $_POST['fio'];
$date = $_POST['date'];
$time = $_POST['time'];

if (!empty($fio) && !empty($date) && !empty($time)) {
    
    $write = "INSERT INTO `visit` (id, visitorFIO, visitDate, visitTime) VALUES (NULL, '$fio', '$date', '$time:00')"; 
    $query = mysqli_query($mysqli, $write);
     if ($query == true) {
         echo "Запись занесена ";
     } else {
         echo "Ошибка";
     }
} else {
    echo "Заполните все поля";
}

?>  

    </div>
</body>
</html>